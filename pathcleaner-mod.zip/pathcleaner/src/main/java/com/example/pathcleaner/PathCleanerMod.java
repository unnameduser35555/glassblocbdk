package com.example.pathcleaner;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

/**
 * PathCleaner Mod — メインクラス
 *
 * 機能:
 *   棒 (Items.STICK) を手に持って Dirt Path (道ブロック) を右クリックすると、
 *   BFS (幅優先探索) でそこから連結しているすべての Dirt Path を
 *   Grass Block (草ブロック) に変換する。
 *
 * 設計方針:
 *   - サーバー側のみで処理を実行し、クライアントへは setBlockState で自動同期
 *   - HashSet で訪問済み座標を管理し、同じブロックを二重処理しない
 *   - 1 回の操作で最大 MAX_BLOCKS ブロックを処理し、それ以上は安全機構で停止
 *   - 棒は消費しない
 *   - サバイバル・クリエイティブ両方で動作する
 */
public class PathCleanerMod implements ModInitializer {

    // =========================================================================
    // 定数・フィールド
    // =========================================================================

    /** MOD ID — fabric.mod.json の "id" フィールドと一致させること */
    public static final String MOD_ID = "pathcleaner";

    /** ロガー — ログ出力に使用 */
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /**
     * 1 回の BFS で処理できる最大ブロック数 (安全機構)
     * 100,000 を超えた場合はそこで探索を打ち切る
     */
    private static final int MAX_BLOCKS = 100_000;

    // =========================================================================
    // ModInitializer#onInitialize — MOD 初期化エントリポイント
    // =========================================================================

    @Override
    public void onInitialize() {
        LOGGER.info("[PathCleaner] 初期化中...");

        // ── ブロック右クリックイベントを登録 ──────────────────────────────────
        // UseBlockCallback.EVENT は Fabric API が提供する右クリック (UseBlock) イベント。
        // 引数: (PlayerEntity player, World world, Hand hand, BlockHitResult hitResult)
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {

            // ── 1. サーバー側のみ処理 ─────────────────────────────────────────
            // world.isClient() が true のときはクライアント側なのでスキップ。
            // setBlockState が内部でクライアントへ変更を伝達するため、
            // サーバー側だけで処理すれば正しく同期される。
            if (world.isClient()) {
                return ActionResult.PASS;
            }

            // ── 2. メインハンドのみ受け付ける ────────────────────────────────
            // Hand.MAIN_HAND と Hand.OFF_HAND の両方でイベントが発火するため、
            // オフハンドの二重発火を防いでメインハンドのみを処理対象にする。
            if (hand != Hand.MAIN_HAND) {
                return ActionResult.PASS;
            }

            // ── 3. 手に持っているアイテムが棒か確認 ──────────────────────────
            // getStackInHand() で指定ハンドのアイテムスタックを取得し、
            // isOf(Items.STICK) で棒かどうかを判定する。
            if (!player.getStackInHand(hand).isOf(Items.STICK)) {
                return ActionResult.PASS; // 棒でなければ何もしない
            }

            // ── 4. 右クリックしたブロックが Dirt Path か確認 ─────────────────
            // hitResult.getBlockPos() でクリックしたブロックの座標を取得し、
            // getBlockState().isOf(Blocks.DIRT_PATH) で Dirt Path か判定する。
            BlockPos clickedPos = hitResult.getBlockPos();
            if (!world.getBlockState(clickedPos).isOf(Blocks.DIRT_PATH)) {
                return ActionResult.PASS; // Dirt Path でなければ何もしない
            }

            // ── 5. BFS で連結している Dirt Path をすべて Grass Block に変換 ──
            int convertedCount = convertConnectedPaths(world, clickedPos);

            // 変換結果をサーバーログに出力
            LOGGER.info("[PathCleaner] {} が {} 個のブロックを変換 (起点: {})",
                    player.getName().getString(), convertedCount, clickedPos);

            // ActionResult.SUCCESS を返すと:
            //   ① デフォルトのブロック操作をキャンセルする
            //   ② クライアントにアーム振りアニメーションを送信する
            //   ③ 上記①②によりクライアントと正しく同期が取れる
            return ActionResult.SUCCESS;
        });

        LOGGER.info("[PathCleaner] 初期化完了");
    }

    // =========================================================================
    // BFS 探索・変換処理
    // =========================================================================

    /**
     * BFS (幅優先探索) を使って startPos を起点に連結している
     * すべての Dirt Path ブロックを Grass Block へ変換する。
     *
     * <p>アルゴリズム概要:</p>
     * <pre>
     *   1. startPos をキュー (ArrayDeque) と訪問済みセット (HashSet) に追加
     *   2. キューが空になるまで繰り返す:
     *      a. キューの先頭から座標を取り出す
     *      b. そのブロックを Grass Block に置き換える (setBlockState)
     *      c. 上下前後左右 (6方向) の隣接ブロックをチェック
     *      d. 未訪問かつ Dirt Path であればキューと訪問済みセットに追加
     *   3. MAX_BLOCKS に達したら警告を出して打ち切り (無限ループ・メモリ過大防止)
     * </pre>
     *
     * <p>HashSet による訪問済み管理の効果:</p>
     * <ul>
     *   <li>同じブロックを複数回キューに追加しない</li>
     *   <li>contains() が O(1) のため探索が高速</li>
     * </ul>
     *
     * @param world    ワールドオブジェクト (サーバー側)
     * @param startPos 探索の起点となるブロック座標
     * @return 変換したブロックの総数
     */
    private static int convertConnectedPaths(World world, BlockPos startPos) {

        // ── BFS 用キュー (FIFO: 先入れ先出し) ──────────────────────────────
        // ArrayDeque は LinkedList より高速でメモリ効率も良い
        Queue<BlockPos> queue = new ArrayDeque<>();

        // ── 訪問済み管理 HashSet ─────────────────────────────────────────────
        // BlockPos は equals() / hashCode() を X, Y, Z 座標で実装しているため
        // HashSet に安全に格納できる
        Set<BlockPos> visited = new HashSet<>();

        // 起点を初期登録
        queue.add(startPos);
        visited.add(startPos);

        int convertedCount = 0; // 変換済みブロック数カウンター

        // ── BFS メインループ ──────────────────────────────────────────────────
        while (!queue.isEmpty()) {

            // ── 安全機構: 上限ブロック数チェック ─────────────────────────────
            // MAX_BLOCKS に達したら探索を打ち切る。
            // これにより、広大な道ブロックの連結でも
            // メモリ枯渇やサーバーフリーズを防止できる。
            if (convertedCount >= MAX_BLOCKS) {
                LOGGER.warn("[PathCleaner] 上限 {} ブロックに達したため探索を停止。"
                        + " キュー残り {} 個。",
                        MAX_BLOCKS, queue.size());
                break;
            }

            // ── キューの先頭から座標を取り出す ───────────────────────────────
            BlockPos current = queue.poll();

            // ── 現在のブロックを Grass Block に置き換える ────────────────────
            // setBlockState(pos, state) のデフォルトフラグ = 3
            //   = NOTIFY_NEIGHBORS (1) | SEND_TO_CLIENT (2)
            // これにより隣接ブロックへの変更通知と、クライアントへの同期が行われる
            world.setBlockState(current, Blocks.GRASS_BLOCK.getDefaultState());
            convertedCount++;

            // ── 6 方向の隣接ブロックを確認 ───────────────────────────────────
            // Direction.values() が返す順序: DOWN, UP, NORTH, SOUTH, WEST, EAST
            for (Direction direction : Direction.values()) {

                // 隣接ブロックの座標を計算
                // BlockPos.offset(Direction) は新しい BlockPos インスタンスを返す
                BlockPos neighbor = current.offset(direction);

                // ── 未訪問の座標のみ処理 (HashSet で O(1) 判定) ──────────────
                if (!visited.contains(neighbor)) {

                    // キューに追加する前に訪問済みとしてマーク
                    // ※ここでマークしないと同じ座標が複数回キューに入る可能性がある
                    visited.add(neighbor);

                    // 隣接ブロックが Dirt Path であればキューに追加して次回以降に処理
                    if (world.getBlockState(neighbor).isOf(Blocks.DIRT_PATH)) {
                        queue.add(neighbor);
                    }
                }
            }
        }

        return convertedCount;
    }
}
